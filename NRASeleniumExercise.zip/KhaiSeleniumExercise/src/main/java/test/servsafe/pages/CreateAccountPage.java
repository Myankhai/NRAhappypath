package test.servsafe.pages;

import Utils.BrowserUtils;
import Utils.ConfigReader;
import com.github.javafaker.Faker;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

import java.util.Random;
import java.util.concurrent.ThreadLocalRandom;

public class CreateAccountPage {


    public CreateAccountPage(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    private Faker faker = new Faker(); // making an instance of faker which generates random data

    public String email = "larrythecrab33" + "+" + faker.random().nextInt(0, 999).toString() + "@" + "gmail.com";

    public String randomFirstName = faker.name().firstName();

    public String getRandomFirstName() {
        return randomFirstName;
    }

    public String getEmail() {
        System.out.println(email);
        return email;
    }

    @FindBy(xpath = "//span[@class='ppClose']")
    WebElement cookiesPopup;

    @FindBy(xpath = "//a[@href='/access/SS/UserProfile/UserLogin']")
    WebElement loginCreateHomePage;

    @FindBy(id = "createAccount-Btn")
    WebElement createAccountButton;

    @FindBy(id = "emailToCheck")
    WebElement emailAddressBox;

    @FindBy(id = "doCheckUniquenessButton")
    WebElement submitBox;

    @FindBy(id = "givenName")
    WebElement firstNameBox;

    @FindBy(id = "sn")
    WebElement lastNameBox;

    @FindBy(id = "emailType")
    WebElement emailTypeDropDown;

    @FindBy(id = "mail-confirm")
    WebElement confirmEmailTextBox;

    @FindBy(id = "addressType")
    WebElement addressTypeDropDown;

    @FindBy(id = "address1")
    WebElement address1Box;

    @FindBy(id = "city")
    WebElement cityBox;

    @FindBy(id = "country")
    WebElement countryDropDown;

    @FindBy(id = "state")
    WebElement stateProvinceRegionDropDown;

    @FindBy(id = "zipCode")
    WebElement zipPostalCodeBox;

    @FindBy(id = "mobileCountry")
    WebElement mobileCountryDropDown;

    @FindBy(id = "phoneNumber")
    WebElement phoneNumberBox;

    @FindBy(id = "jobRole")
    WebElement jobRoleDropDown;

    @FindBy(id = "password")
    WebElement passwordBox;

    @FindBy(id = "confirmPassword")
    WebElement confirmPasswordBox;

    @FindBy(id = "submitButton")
    WebElement createAccountSubmit;

    @FindBy(id = "Passcode")
    WebElement verificationCodeBox;

    @FindBy(id = "submitBtn")
    WebElement continueVerificationBox;

    @FindBy(xpath = "//button[.='Go to My Account']")
    WebElement goToAccountBox;

    @FindBy(xpath = "//span[@id='Account-link']")
    WebElement welcomeUserBox;

    @FindBy(xpath = "//a[.='Log Out']")
    WebElement logOutSubMenuHoverDropDown;

    public void setCreateAccountButton() {


        cookiesPopup.click();
        loginCreateHomePage.click();
        createAccountButton.click();
    }


    public void inputSetup() throws InterruptedException {
        //   Faker faker = new Faker(); // making an instance of faker which generates random data
        //   String email = "larrythecrab33" + "+" + faker.random().nextInt(0, 999) + "@" + "gmail.com";
        //  String randomFirstName = faker.name().firstName();


        emailAddressBox.sendKeys(getEmail());
        submitBox.click();
        firstNameBox.sendKeys(getRandomFirstName());
        lastNameBox.sendKeys(faker.name().lastName());

        BrowserUtils.selectBy(emailTypeDropDown, "Personal", "text");

        confirmEmailTextBox.sendKeys(getEmail());

        BrowserUtils.selectBy(addressTypeDropDown, "Home", "text");

        address1Box.sendKeys("6 E Monroe St");
        cityBox.sendKeys("Chicago");
        BrowserUtils.selectBy(countryDropDown, "United States", "text");
        BrowserUtils.selectBy(stateProvinceRegionDropDown, "Illinois", "text");
        zipPostalCodeBox.sendKeys("60603");
        BrowserUtils.selectBy(mobileCountryDropDown, "United States (+1)", "text");
        phoneNumberBox.sendKeys(faker.phoneNumber().cellPhone());
        BrowserUtils.selectBy(jobRoleDropDown, "Staff/Professional", "text");
        passwordBox.sendKeys(ConfigReader.readProperty("createaccountpass"));
        confirmPasswordBox.sendKeys(ConfigReader.readProperty("createaccountpass"));
        createAccountSubmit.click();


        Thread.sleep(60000); // 60 seconds to manually input the throwaway gmail and input the verification code

        continueVerificationBox.click();
        goToAccountBox.click();

        Thread.sleep(3000);
        Assert.assertEquals(welcomeUserBox.getText().toLowerCase(), "welcome " + getRandomFirstName().toLowerCase());


    }


}
