package test.servsafe.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.devtools.v85.page.Page;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class GmailLoginPage {

    public GmailLoginPage(WebDriver driver) {
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//input[@autocomplete='username']")
    WebElement username;

    @FindBy(xpath = "//span[.='Next']")
    WebElement next;


        /*
    driver.switchTo().newWindow(WindowType.TAB);
         Set<String> allPageIds = driver.getWindowHandles();
        for(String id:allPageIds){
            if(!actual.equalsIgnoreCase(driver.getCurrentUrl())){
                driver.switchTo().window(actual);
                driver.get("https://www.google.com/gmail/about/)";
            }
        }
*/

    /*
    To help keep your account secure, from May 30, 2022,Google no longer supports the use of
    third-party apps or devices which ask you to sign in to your Google Account using only your username and password.
Important: This deadline does not apply to Google Workspace or Google Cloud Identity customers.
 The enforcement date for these customers will be announced on the Workspace blog at a later date.
For more information, continue to read.
     */

    // Apparently there's a solution to overcoming automation block with python using the "selenium-stealth" module.


}
