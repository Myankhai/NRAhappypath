package test.servsafe.pages;

import Utils.ConfigReader;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class LoginExistingAccountPage {

    public LoginExistingAccountPage(WebDriver driver) {
        PageFactory.initElements(driver, this);

    }

    @FindBy(xpath = "//span[@class='ppClose']")
    WebElement cookiesPopup;

    @FindBy(xpath = "//a[@href='/access/SS/UserProfile/UserLogin']")
    WebElement loginCreateHomePage;

    @FindBy(id = "username")
    WebElement emailBox;

    @FindBy(id = "password")
    WebElement passwordBox;

    @FindBy(xpath = "//a[@title='servsafe.html.form.login.template. signInButtonTitle']")
    WebElement login;

    @FindBy(xpath = "//span[@id='Account-link']")
    WebElement welcomeUserBox;

    @FindBy(xpath = "//a[.='Log Out']")
    WebElement logOutSubMenuHoverDropDown;

    public void login(String email) throws InterruptedException {

        Thread.sleep(5000);

        loginCreateHomePage.click();
        emailBox.sendKeys(email);
        passwordBox.sendKeys(ConfigReader.readProperty("createaccountpass"));
        login.click();

    }

    public void logOut() {
        logOutSubMenuHoverDropDown.click();

        Assert.assertEquals(loginCreateHomePage.getText(), "Login / Create Account");
    }

}
