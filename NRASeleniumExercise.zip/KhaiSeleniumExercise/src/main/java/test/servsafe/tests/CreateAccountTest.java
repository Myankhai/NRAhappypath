package test.servsafe.tests;

import Utils.BrowserUtils;
import Utils.ConfigReader;
import Utils.DriverHelper;
import com.github.javafaker.Faker;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.WindowType;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;
import test.servsafe.pages.CreateAccountPage;
import test.servsafe.pages.LoginExistingAccountPage;
import test.servsafe.servsafeintl.pages.HomePage;

import java.time.Duration;
import java.util.Set;
import java.util.concurrent.TimeUnit;

public class CreateAccountTest extends TestBase {


    @Test
    public void createAccountTest() throws InterruptedException {
        /*      user:  larrythecrab33@gmail.com
                pass:  He!enK3ll3r
                                              */


        CreateAccountPage createAccountPage = new CreateAccountPage(driver);
        createAccountPage.setCreateAccountButton();


        Assert.assertEquals(driver.getTitle(), "Create Your Account");

        createAccountPage.inputSetup();

        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(By.xpath("//span[@id='Account-link']")));
        WebElement subMenuLogOut = driver.findElement(By.xpath("//a[.='Log Out']"));
        actions.moveToElement(subMenuLogOut);
        actions.click().build().perform();


        LoginExistingAccountPage loginExistingAccountPage = new LoginExistingAccountPage(driver);
        loginExistingAccountPage.login(createAccountPage.getEmail());

        actions = new Actions(driver); //re-initializing lines 51-54 to prevent staleElementException

        actions.moveToElement(driver.findElement(By.xpath("//span[@id='Account-link']")));
        WebElement subMenuLogout2 = driver.findElement(By.xpath("//a[.='Log Out']"));
        actions.moveToElement(subMenuLogout2);
        driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
        actions.click().build().perform();

        HomePage homePage = new HomePage(driver);
        driver.get(ConfigReader.readProperty("servsafeintl"));
        String servSafeInternationalTitle = driver.getTitle();
        Assert.assertTrue(driver.getTitle().equals(servSafeInternationalTitle));
        homePage.login(createAccountPage.getEmail());

        Assert.assertEquals(driver.findElement(By.xpath("//div[@id='username']")).getText().toLowerCase(), "welcome " + createAccountPage.getRandomFirstName().toLowerCase());

        homePage.logOut();

    }


    // Faker library would use a separate instance of generated email/name under a different driver initialization from @beforemethod

/*    @Test

    public void loginLogout() throws InterruptedException {
        CreateAccountPage createAccountPage = new CreateAccountPage(driver);
        LoginExistingAccountPage loginExistingAccountPage = new LoginExistingAccountPage(driver);
        loginExistingAccountPage.login(createAccountPage.getEmail());

        Actions actions = new Actions(driver);
        actions.moveToElement(driver.findElement(By.xpath("//span[@id='Account-link']")));
        WebElement subMenuLogOut = driver.findElement(By.xpath("//a[.='Log Out']"));
        actions.moveToElement(subMenuLogOut);
        actions.click().build().perform();

        HomePage homePage = new HomePage(driver);
        driver.get(ConfigReader.readProperty("servsafeintl"));
        String servSafeInternationalTitle= driver.getTitle();
        Assert.assertTrue(driver.getTitle().equals(servSafeInternationalTitle));
        homePage.login(createAccountPage.getEmail());
        Assert.assertEquals(driver.findElement(By.xpath("//div[@id='username']")).getText().toLowerCase(), "welcome " + createAccountPage.getRandomFirstName().toLowerCase());
        homePage.logOut();
    }*/


}
