package test.servsafe.tests;

import com.github.javafaker.Faker;

public class Hmm {

    public static void main(String[] args) {

        Faker faker = new Faker();

        String email = "larrythecrab33" + "+" + faker.random().nextInt(0, 999) + "@gmail.com";

        System.out.println(email);
    }
}
