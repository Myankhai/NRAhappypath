package test.servsafe.tests;

import Utils.BrowserUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

public class ExamTest extends TestBase {
    private String user = "nraregression+20221022073942@gmail.com";
    private String pass = "Password@233";

    @Test
    public void examTest() {
        WebElement loginCreateAccount = driver.findElement(By.xpath("//a[@href='/access/SS/UserProfile/UserLogin']"));
        loginCreateAccount.click();

        WebElement email = driver.findElement(By.id("username"));
        WebElement password = driver.findElement(By.id("password"));
        WebElement loginButton = driver.findElement(By.xpath("//a[@title='servsafe.html.form.login.template. signInButtonTitle']"));

        email.sendKeys(user);
        password.sendKeys(pass);
        loginButton.click();

        WebElement servSafeFoodHandler = driver.findElement(By.xpath("//*[@id=\"masthead\"]/nav/div[2]/div[1]/ul/li[2]/a"));
        servSafeFoodHandler.click();

        WebElement takeOnlineExam = driver.findElement(By.xpath("//*[@id=\"masthead\"]/nav/div[4]/div/ul/li[2]/a"));
        takeOnlineExam.click();

        WebElement selectCourse = driver.findElement(By.xpath("//select[@id='ctl00_ctl00_BaseMainContentPlaceHolder_MainContentPlaceHolder_ddlExam']"));
        BrowserUtils.selectBy(selectCourse,"ServSafe Food Handler Online Assessment","text");

        WebElement welcomeExamineeHeader = driver.findElement(By.xpath("//*[@id=\"subMain\"]/div/div/div[1]/h3"));
        Assert.assertTrue(welcomeExamineeHeader.isDisplayed());

        WebElement codeOfConductBox = driver.findElement(By.xpath("//input[@id='ctl00_MainContentPlaceHolder_CGICheckBox1']"));
        codeOfConductBox.click();

        WebElement continueBox = driver.findElement(By.xpath("//a[@id='ctl00_MainContentPlaceHolder_cmdNext']"));
        continueBox.click();

        WebElement courseAccessKeyRequired = driver.findElement(By.xpath("//*[@id=\"ctl00_MainContentPlaceHolder_objValidationSummary\"]/tbody/tr/td"));
        Assert.assertTrue(courseAccessKeyRequired.isDisplayed());
    }
}
