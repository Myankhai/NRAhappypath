package test.servsafe.servsafeintl.pages;

import Utils.ConfigReader;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class HomePage {

    public HomePage(WebDriver driver) {
        PageFactory.initElements(driver, this);

    }

    @FindBy(tagName = "title")
    WebElement pageTitle;

    @FindBy(xpath = "//a[contains(text(),'Login')]")
    WebElement loginRedirectBox;

    @FindBy(id = "username")
    WebElement emailBox;

    @FindBy(id = "password")
    WebElement passwordBox;

    @FindBy(xpath = "//a[@title='servsafe.html.form.login.template. signInButtonTitle']")
    WebElement loginConfirmBox;

    @FindBy(xpath = "//a[@href='/ss/common/Actions.aspx?action=logout']")
    WebElement logOutHoverDropDown;

    @FindBy(id = "username")
    WebElement loggedInUsername;

    @FindBy(id = "ctl00_lnkSiteLogout")
    WebElement logOutButton;

    public void login(String email) {


        loginRedirectBox.click();
        emailBox.sendKeys(email);
        passwordBox.sendKeys(ConfigReader.readProperty("createaccountpass"));

        loginConfirmBox.click();


    }

    public void logOut() {
        logOutButton.click();
        Assert.assertTrue(loginRedirectBox.isDisplayed());

    }

}
